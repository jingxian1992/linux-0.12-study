#include <stdio.h>
#include <linux/sched.h>
#include <string.h>
#include <asm/io.h>
#include <asm/system.h>
#include <asm/segment.h>
#include <unistd.h>

#ifndef MAJOR_NR
#define MAJOR_NR 3
#endif
#include <linux/blk.h>

#define ORIG_SWAP_DEV *(unsigned short *)0x90000
#define ORIG_ROOT_DEV *(unsigned short *)0x90002

extern void start_kernel(void);
extern void con_init(void);
extern void trap_init(void);
extern void tty_init(void);
extern void chr_dev_init(void);
extern void time_init(void);
extern void inode_table_init(void);
extern void file_table_init(void);
extern void super_block_init(void);
extern void system_info_init(void);
extern void task_init(void);

void main(void)
{
	pg_dir = (unsigned int *)0;
	idt = (struct desc_struct *)0x13000;
	gdt = (struct desc_struct *)0x13800;
	start_kernel();
	return;
}

static int memory_end;
static int buffer_memory_end;
static int main_memory_start;

void start_kernel(void)
{
	int i, sum;
	int res;

	SWAP_DEV = ORIG_SWAP_DEV;
	ROOT_DEV = ORIG_ROOT_DEV;
	memory_end = 0x4000000;
	buffer_memory_end = 0xD00000;
	main_memory_start = buffer_memory_end;
	
	con_init();
	mem_init(main_memory_start, memory_end);
	trap_init();
	blk_dev_init();
	tty_init();
	chr_dev_init();
	time_init();
	sched_init();
	buffer_init(buffer_memory_end);
	hd_init();
	inode_table_init();
	file_table_init();
	super_block_init();
	file_table_init();
	system_info_init();
	sti();
	
	printk("\twelcome to Dumpling OS.\n");
	printk("\tmemory volume: %dM\n", memory_end/0x100000);
	sys_load_flags = 0;
	move_to_user_mode();
	
	__asm__ __volatile__ (
	"int $0x80\n\t":"=a"(res):"0"(__NR_fork):);

	if (!res)
	{
		task_init();
	}

	for(;;)
		__asm__("int $0x80"::"a" (__NR_pause));
}

extern void sync_task(void);
extern void test_task(void);
extern void task_init(void)
{
	char * cmd_buf;
	void * tmp;
	int res, len;

	setup();
	malloc_page(&tmp);
	cmd_buf = (char *)tmp;	
	start_shell();
	
	res = fork();
	if (!res)
	{
		sync_task();
	}
	
	res = fork();
	if (!res)
	{
		test_task();
	}
	
	while(1)
	{
		res = wait_return();
		if (res)
		{
			len = read_simple(cmd_buf + 1024);
			shell_manage(cmd_buf, len);
		}
		else;
	}
}

extern void sync_task(void)
{
	while (1)
	{
		sync();
	}
}

extern void test_task(void)
{
	while(1);
}

