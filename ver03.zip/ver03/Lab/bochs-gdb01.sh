	/home/study/C_SYS/bochs-gdb01/bin/bochs -f gdb.bxrc
